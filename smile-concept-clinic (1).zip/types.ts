
export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  iconName: 'Sparkles' | 'Activity' | 'Smile' | 'PenTool' | 'Zap' | 'Baby';
}

export interface Message {
  role: 'user' | 'model';
  text: string;
}

export enum ChatStatus {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  ERROR = 'ERROR'
}

export interface NavigationProps {
  onNavigate: (page: 'home' | 'contact', hash?: string) => void;
}
