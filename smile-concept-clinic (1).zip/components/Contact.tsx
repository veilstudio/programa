
import React, { useState } from 'react';
import { MapPin, Phone, Mail, Instagram, Clock, Send } from 'lucide-react';

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would send to backend. Here we simulate.
    const mailtoLink = `mailto:smileconcept2024@gmail.com?subject=Pedido de Consulta - ${formData.name}&body=Nome: ${formData.name}%0D%0AContacto: ${formData.phone}%0D%0AMensagem: ${formData.message}`;
    window.location.href = mailtoLink;
  };

  return (
    <section id="contact" className="pt-32 pb-20 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          
          {/* Contact Info Side */}
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Entre em Contacto</h2>
            <p className="text-lg text-gray-600 mb-10">
              Estamos prontos para o receber. Visite-nos na nossa clínica, ligue ou envie uma mensagem para marcar a sua avaliação.
            </p>

            <div className="space-y-8">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-white shadow-sm text-primary border border-gray-100">
                    <MapPin className="h-6 w-6" />
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">Localização</h3>
                  <p className="mt-1 text-gray-600">Rua da Fé, Nº55 loja 2</p>
                  <a 
                    href="https://www.google.com/maps/search/?api=1&query=Rua+da+Fé+N55+loja+2" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary hover:text-sky-700 font-medium text-sm mt-1 inline-block"
                  >
                    Ver no Google Maps &rarr;
                  </a>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-white shadow-sm text-primary border border-gray-100">
                    <Phone className="h-6 w-6" />
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">Telefones</h3>
                  <div className="mt-1 flex flex-col gap-1">
                    <a href="tel:265424001" className="text-gray-600 hover:text-primary transition-colors">265 424 001</a>
                    <a href="tel:936462557" className="text-gray-600 hover:text-primary transition-colors">936 462 557</a>
                  </div>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-white shadow-sm text-primary border border-gray-100">
                    <Mail className="h-6 w-6" />
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">Email</h3>
                  <a href="mailto:smileconcept2024@gmail.com" className="mt-1 text-gray-600 hover:text-primary block">
                    smileconcept2024@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-white shadow-sm text-pink-600 border border-gray-100">
                    <Instagram className="h-6 w-6" />
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">Instagram</h3>
                  <a 
                    href="https://instagram.com/smileconcept2024" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="mt-1 text-gray-600 hover:text-pink-600 font-medium block"
                  >
                    @smileconcept2024
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Form Side */}
          <div className="bg-white rounded-2xl shadow-lg p-8 lg:p-10 border border-gray-100">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Pedir Contacto</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Nome Completo</label>
                <input
                  type="text"
                  name="name"
                  id="name"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  className="mt-1 block w-full px-4 py-3 rounded-lg border border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm bg-gray-50 transition-colors"
                  placeholder="Seu nome"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Telemóvel</label>
                <input
                  type="tel"
                  name="phone"
                  id="phone"
                  required
                  value={formData.phone}
                  onChange={handleChange}
                  className="mt-1 block w-full px-4 py-3 rounded-lg border border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm bg-gray-50 transition-colors"
                  placeholder="9xx xxx xxx"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700">Mensagem (Opcional)</label>
                <textarea
                  name="message"
                  id="message"
                  rows={4}
                  value={formData.message}
                  onChange={handleChange}
                  className="mt-1 block w-full px-4 py-3 rounded-lg border border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm bg-gray-50 transition-colors"
                  placeholder="Diga-nos qual o motivo da consulta..."
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full flex items-center justify-center px-8 py-4 border border-transparent text-base font-semibold rounded-lg text-white bg-primary hover:bg-sky-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all shadow-md hover:shadow-lg"
              >
                Enviar Pedido <Send className="ml-2 h-4 w-4" />
              </button>
              <p className="text-xs text-gray-500 text-center mt-4">
                Ao enviar, irá abrir o seu cliente de email padrão.
              </p>
            </form>
          </div>

        </div>
      </div>
    </section>
  );
};
