
import React from 'react';
import { Facebook, Instagram, Linkedin } from 'lucide-react';
import { NavigationProps } from '../types';

export const Footer: React.FC<NavigationProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          
          {/* Brand */}
          <div>
             <div className="flex items-center gap-2 mb-4">
              <div className="bg-white/10 p-2 rounded-lg">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" x2="9.01" y1="9" y2="9"/><line x1="15" x2="15.01" y1="9" y2="9"/><path d="M12 2a10 10 0 1 0 0 20 10 10 0 1 0 0-20z"/></svg>
              </div>
              <span className="text-xl font-bold">Smile Concept</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              O seu sorriso é a nossa prioridade. Tecnologia de ponta, profissionais experientes e um ambiente acolhedor à sua espera em Setúbal.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-gray-200">Links Rápidos</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><button onClick={() => onNavigate('home')} className="hover:text-primary transition-colors text-left">Início</button></li>
              <li><button onClick={() => onNavigate('home', 'services')} className="hover:text-primary transition-colors text-left">Serviços</button></li>
              <li><button onClick={() => onNavigate('home', 'about')} className="hover:text-primary transition-colors text-left">Sobre Nós</button></li>
              <li><button onClick={() => onNavigate('contact')} className="hover:text-primary transition-colors text-left">Agendar Consulta</button></li>
            </ul>
          </div>

          {/* Social & Legal */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-gray-200">Siga-nos</h4>
            <div className="flex space-x-4">
              <a href="https://instagram.com/smileconcept2024" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-pink-600 transition-colors">
                <Instagram size={20} />
              </a>
              {/* Placeholders for other social media if added later */}
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-blue-600 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-blue-700 transition-colors">
                <Linkedin size={20} />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500">
          <p>&copy; {new Date().getFullYear()} Smile Concept. Todos os direitos reservados.</p>
          <div className="flex gap-4 mt-4 md:mt-0">
            <a href="#" className="hover:text-gray-300">Política de Privacidade</a>
            <a href="#" className="hover:text-gray-300">Termos de Uso</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
