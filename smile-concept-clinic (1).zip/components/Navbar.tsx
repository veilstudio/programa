
import React, { useState } from 'react';
import { Menu, X, Phone, Instagram, MapPin } from 'lucide-react';
import { NavigationProps } from '../types';

export const Navbar: React.FC<NavigationProps> = ({ onNavigate }) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen(!isOpen);

  const handleLinkClick = (e: React.MouseEvent, page: 'home' | 'contact', hash?: string) => {
    e.preventDefault();
    onNavigate(page, hash);
    setIsOpen(false);
  };

  return (
    <nav className="bg-white shadow-md fixed w-full z-50 top-0 left-0">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          {/* Logo Section */}
          <a href="#" onClick={(e) => handleLinkClick(e, 'home')} className="flex-shrink-0 flex items-center gap-2 group">
            <div className="bg-primary text-white p-2 rounded-lg group-hover:bg-sky-600 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" x2="9.01" y1="9" y2="9"/><line x1="15" x2="15.01" y1="9" y2="9"/><path d="M12 2a10 10 0 1 0 0 20 10 10 0 1 0 0-20z"/></svg>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800 leading-tight">Smile Concept</h1>
              <p className="text-xs text-gray-500 tracking-wider">CLÍNICA DENTÁRIA</p>
            </div>
          </a>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <button
              onClick={(e) => handleLinkClick(e, 'home')}
              className="text-gray-600 hover:text-primary transition-colors font-medium text-sm uppercase tracking-wide"
            >
              Início
            </button>
            <button
              onClick={(e) => handleLinkClick(e, 'home', 'services')}
              className="text-gray-600 hover:text-primary transition-colors font-medium text-sm uppercase tracking-wide"
            >
              Serviços
            </button>
            <button
              onClick={(e) => handleLinkClick(e, 'home', 'about')}
              className="text-gray-600 hover:text-primary transition-colors font-medium text-sm uppercase tracking-wide"
            >
              Sobre
            </button>
            <button
              onClick={(e) => handleLinkClick(e, 'contact')}
              className="text-gray-600 hover:text-primary transition-colors font-medium text-sm uppercase tracking-wide"
            >
              Contactos
            </button>
            <a 
              href="tel:936462557"
              className="bg-primary hover:bg-sky-600 text-white px-5 py-2.5 rounded-full font-medium transition-all shadow-sm hover:shadow-md flex items-center gap-2"
            >
              <Phone size={18} />
              <span>Ligar Agora</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={toggleMenu}
              className="text-gray-600 hover:text-gray-900 focus:outline-none p-2"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-gray-100">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 shadow-lg">
            <button
              onClick={(e) => handleLinkClick(e, 'home')}
              className="block w-full text-left px-3 py-3 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50"
            >
              Início
            </button>
            <button
              onClick={(e) => handleLinkClick(e, 'home', 'services')}
              className="block w-full text-left px-3 py-3 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50"
            >
              Serviços
            </button>
            <button
              onClick={(e) => handleLinkClick(e, 'home', 'about')}
              className="block w-full text-left px-3 py-3 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50"
            >
              Sobre
            </button>
            <button
              onClick={(e) => handleLinkClick(e, 'contact')}
              className="block w-full text-left px-3 py-3 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50"
            >
              Contactos
            </button>
            
            <div className="mt-4 pt-4 border-t border-gray-100 flex flex-col gap-3 px-3">
               <a href="tel:265424001" className="flex items-center gap-3 text-gray-600">
                  <Phone size={18} className="text-primary"/> 265 424 001
               </a>
               <a href="https://instagram.com/smileconcept2024" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 text-gray-600">
                  <Instagram size={18} className="text-pink-600"/> @smileconcept2024
               </a>
               <button onClick={(e) => handleLinkClick(e, 'contact')} className="flex items-center gap-3 text-gray-600">
                  <MapPin size={18} className="text-secondary"/> Rua da Fé, Nº55 loja 2
               </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};
