
import React from 'react';
import { ChevronRight } from 'lucide-react';
import { NavigationProps } from '../types';

export const Hero: React.FC<NavigationProps> = ({ onNavigate }) => {
  return (
    <section id="home" className="relative pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
      {/* Background with overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=2068" 
          alt="Clínica Dentária Moderna" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white via-white/90 to-transparent"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-2xl">
          <div className="inline-block bg-sky-100 text-primary px-4 py-1.5 rounded-full text-sm font-semibold mb-6 animate-fade-in-up">
            Bem-vindo à Smile Concept
          </div>
          <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 tracking-tight mb-6 leading-tight">
            Sorrisos que <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-teal-500">
              Transformam Vidas
            </span>
          </h1>
          <p className="text-lg md:text-xl text-gray-600 mb-8 leading-relaxed">
            Cuidamos da sua saúde oral com tecnologia avançada e uma equipa dedicada ao seu conforto. 
            Higiene, Ortodontia, Implantes e muito mais num só lugar.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={() => onNavigate('contact')}
              className="inline-flex items-center justify-center px-8 py-3.5 border border-transparent text-base font-semibold rounded-lg text-white bg-primary hover:bg-sky-600 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              Marcar Consulta
              <ChevronRight className="ml-2 -mr-1 h-5 w-5" />
            </button>
            <button 
              onClick={() => onNavigate('home', 'services')}
              className="inline-flex items-center justify-center px-8 py-3.5 border border-gray-300 text-base font-semibold rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition-all shadow-sm"
            >
              Ver Serviços
            </button>
          </div>

          <div className="mt-12 flex items-center gap-6 text-sm font-medium text-gray-500">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500"></span>
              Aberto hoje até às 19:00
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-primary"></span>
              Aceitamos novos pacientes
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
