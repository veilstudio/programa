import React from 'react';
import { Sparkles, Activity, Smile, PenTool, Zap, Baby } from 'lucide-react';
import { ServiceItem } from '../types';

const services: ServiceItem[] = [
  {
    id: 'higiene',
    title: 'Higiene Oral',
    description: 'Limpezas profundas, destartarização e prevenção de doenças gengivais para um sorriso sempre fresco.',
    iconName: 'Sparkles',
  },
  {
    id: 'endodontia',
    title: 'Endodontia',
    description: 'Tratamento de canais (desvitalização) para salvar dentes danificados e aliviar a dor.',
    iconName: 'Activity', // Root substitute
  },
  {
    id: 'ortodontia',
    title: 'Ortodontia',
    description: 'Correção da posição dos dentes e maxilares com aparelhos fixos ou alinhadores invisíveis.',
    iconName: 'Smile', // Braces substitute
  },
  {
    id: 'dentisteria',
    title: 'Dentisteria',
    description: 'Restauração de dentes fraturados ou com cáries, devolvendo a estética e função natural.',
    iconName: 'PenTool', // Drill substitute
  },
  {
    id: 'implantologia',
    title: 'Implantologia',
    description: 'Substituição de dentes perdidos através de implantes dentários seguros e duradouros.',
    iconName: 'Zap', // Screw substitute
  },
  {
    id: 'odontopediatria',
    title: 'Odontopediatria',
    description: 'Cuidado especializado para crianças, garantindo que os pequenos crescem com um sorriso saudável.',
    iconName: 'Baby',
  },
];

const IconMap: Record<string, React.ElementType> = {
  Sparkles,
  Activity,
  Smile,
  PenTool,
  Zap,
  Baby
};

export const Services: React.FC = () => {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-primary font-semibold tracking-wide uppercase text-sm mb-2">Especialidades</h2>
          <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Tratamentos Completos para Toda a Família</h3>
          <p className="text-lg text-gray-600">
            Na Smile Concept, oferecemos uma gama abrangente de cuidados dentários, utilizando as técnicas mais modernas para garantir o seu conforto.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => {
            const Icon = IconMap[service.iconName];
            return (
              <div 
                key={service.id} 
                className="group p-8 bg-slate-50 rounded-2xl border border-slate-100 hover:border-primary/30 hover:shadow-xl hover:bg-white transition-all duration-300"
              >
                <div className="w-14 h-14 bg-white rounded-xl shadow-sm flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-white transition-colors text-primary">
                  <Icon size={32} strokeWidth={1.5} />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h4>
                <p className="text-gray-600 leading-relaxed">
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};