
import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { ChatWidget } from './components/ChatWidget';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<'home' | 'contact'>('home');

  const handleNavigate = (page: 'home' | 'contact', hash?: string) => {
    setCurrentPage(page);
    
    if (page === 'home' && hash) {
      // Use setTimeout to allow the view to render before scrolling
      setTimeout(() => {
        const element = document.getElementById(hash);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      <Navbar onNavigate={handleNavigate} />
      
      <main className="flex-grow">
        {currentPage === 'home' ? (
          <>
            <Hero onNavigate={handleNavigate} />
            
            {/* About Section Teaser placed between Hero and Services */}
            <section id="about" className="py-16 bg-white border-b border-gray-100">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <h2 className="text-3xl font-bold text-gray-900 mb-6">Porque escolher a Smile Concept?</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
                  <div className="flex flex-col items-center text-center p-4">
                     <div className="w-12 h-12 bg-sky-100 text-primary rounded-full flex items-center justify-center mb-4 text-xl font-bold">1</div>
                     <h3 className="text-lg font-semibold mb-2">Equipa Especializada</h3>
                     <p className="text-gray-600">Profissionais experientes em todas as áreas da medicina dentária.</p>
                  </div>
                  <div className="flex flex-col items-center text-center p-4">
                     <div className="w-12 h-12 bg-sky-100 text-primary rounded-full flex items-center justify-center mb-4 text-xl font-bold">2</div>
                     <h3 className="text-lg font-semibold mb-2">Tecnologia Moderna</h3>
                     <p className="text-gray-600">Equipamentos de última geração para diagnósticos precisos.</p>
                  </div>
                  <div className="flex flex-col items-center text-center p-4">
                     <div className="w-12 h-12 bg-sky-100 text-primary rounded-full flex items-center justify-center mb-4 text-xl font-bold">3</div>
                     <h3 className="text-lg font-semibold mb-2">Ambiente Acolhedor</h3>
                     <p className="text-gray-600">Sentir-se bem no dentista é possível. Cuidamos do seu conforto.</p>
                  </div>
                </div>
              </div>
            </section>

            <Services />
            
            {/* Aesthetic Image Banner */}
            <div className="h-64 w-full relative">
                <img 
                  src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&q=80&w=2000" 
                  alt="Consultório Dentário" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-secondary/80 flex items-center justify-center">
                    <div className="text-center text-white px-4">
                        <h3 className="text-3xl md:text-4xl font-bold mb-4">Cuide do seu sorriso hoje</h3>
                        <p className="text-lg opacity-90">Agende a sua consulta de avaliação sem compromisso.</p>
                        <button 
                          onClick={() => handleNavigate('contact')}
                          className="mt-6 inline-block bg-white text-secondary px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors"
                        >
                          Marcar Agora
                        </button>
                    </div>
                </div>
            </div>
          </>
        ) : (
          <Contact />
        )}
      </main>

      <Footer onNavigate={handleNavigate} />
      <ChatWidget />
    </div>
  );
};

export default App;
