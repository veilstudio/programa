import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Initialize the API client
// Note: In a real production app, ensure the API key is restricted or proxied via backend
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SYSTEM_INSTRUCTION = `
Você é a assistente virtual da Clínica Dentária "Smile Concept".
Seu tom é profissional, amigável, empático e informativo.

Dados da Clínica:
- Nome: Smile Concept
- Morada: Rua da Fé, Nº55 loja 2
- Telefones: 265424001 ou 936462557
- Email: smileconcept2024@gmail.com
- Instagram: @smileconcept2024
- Serviços: Higiene oral, Endodontia, Ortodontia, Dentisteria, Implantologia, Odontopediatria.

O seu objetivo é:
1. Responder a dúvidas básicas sobre os tratamentos (ex: o que é endodontia?).
2. Fornecer informações de contacto e localização.
3. Incentivar o agendamento de consultas via telefone ou email.

IMPORTANTE: Você NÃO pode realizar diagnósticos médicos ou prescrever medicamentos. Se o usuário relatar dor, recomende que ligue imediatamente para a clínica.
Responda sempre em Português de Portugal. Seja conciso (máximo 3 frases por resposta, a menos que seja uma explicação técnica necessária).
`;

export const sendMessageToGemini = async (message: string, history: { role: string, parts: { text: string }[] }[]): Promise<string> => {
  try {
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
      history: history
    });

    const response: GenerateContentResponse = await chat.sendMessage({ message });
    return response.text || "Desculpe, não consegui processar a sua resposta no momento. Por favor, tente novamente ou ligue para a clínica.";
  } catch (error) {
    console.error("Erro ao comunicar com Gemini:", error);
    return "Ocorreu um erro temporário na nossa assistente. Por favor, utilize os contactos telefónicos para falar connosco.";
  }
};